#load saves

library(xtable)
load("/Users/philip/Downloads/H11_100_limited_27_august.RData")
load("/Users/philip/Downloads/H11_100_27_august.RData")
load("/Users/philip/Downloads/H11_10_limited_29_august.RData")

mydimnames = list(c("PEHE.all.train","PEHE.tt.train","RMSE.all.train","RMSE.tt.train","E.ate.train","E.att.train","SE.ate.train","SE.att.train","coverage.ite.train","coverage.ate.train","range.ate.train",
                    "PEHE.all.test","PEHE.tt.test","RMSE.all.test","RMSE.tt.test","E.ate.test","E.att.test","SE.ate.test","SE.att.test","coverage.ite.test","coverage.ate.test","range.ate.test"),
                  c("BART","CF","VT-RF","CF-RF","GP","BCF","BART.PS","GP.PS","TP2.PS","TP2000.PS"))

nr_metrix = length(mydimnames[[1]])
nr_models = length(mydimnames[[2]])

out = round(cbind(matrix(apply(results,1,mean),nr_metrix,nr_models),sqrt(matrix(apply(results,1,var),nr_metrix,nr_models))),2)#,matrix(apply(results,1,min),11,7),matrix(apply(results,1,max),11,7)),2)
out2 = matrix(NaN,nr_metrix*2,nr_models)
colnames(out2) <- mydimnames[[2]]
for(i in  1:2){
  for(j in 1:nr_models)
    #    all "means" for method "j" , <-
    out2[(1:nr_metrix -1) * 2 + i, j] <- c(out[,j + nr_models*(i-1) ])
}
colnames(out2) <- mydimnames[[2]]
rownames(out2) <- rep(mydimnames[[1]],each=2)


xtable(out2)


mycol80 <- rgb(191, 191, 191, max=255, alpha = (100-80)*255/100)
mycol60 <- rgb(191, 191, 191, max=255, alpha = (100-60)*255/100)
mycol30 <- rgb(191, 191, 191, max=255, alpha = (100-30)*255/100)
mycol10 <- rgb(191, 191, 191, max=255, alpha = (100-10)*255/100)
mycol5 <- rgb(191, 191, 191, max=255, alpha = (100-5)*255/100)

#PEHE.all train BART
hist(results[1,])
i=5 #2: CF, 5: GP
hist(results[1+nr_metrix*(i-1),])

#PEHE.all test BART
hist(results[12,])
i=5 #2: CF, 5: GP
hist(results[12+nr_metrix*(i-1),])

#ATE bias test BART
hist(results[16,])
i=5 #2: CF, 5: GP, 6: BCF


load("/Users/philip/Downloads/H11_100_27_august.RData")
mymax=0
mymin=0
## ATE bias #####
for(i in 1:nr_models){
  tmp =  max(results[16+nr_metrix*(i-1),])
  if (tmp>mymax){ mymax = tmp }
  tmp =  min(results[16+nr_metrix*(i-1),])
  if (tmp<mymin){ mymin = tmp }
}
mymax=ceiling(mymax)
mymin=floor(mymin)
myseq = seq(mymin,mymax,by=0.2)

window=2
plot_w = 3; plot_h = 1.3

for(i in 1:nr_models){

  {
    hist.test  = hist(results[16+nr_metrix*(i-1),],breaks = myseq)
    hist.train = hist(results[5+nr_metrix*(i-1),],breaks = myseq)#,breaks = seq(-6,6,by=0.2))
  }

  tikz(file = sprintf("IHDP_ATEhisto_full_%d.tex",i), width = plot_w, height = plot_h)
  par(mfrow=c(1,1),mar=c(2.5,2.5,0.1,0.1),mgp=c(1.3,0.3,0),cex.lab=0.8,cex.axis=0.8,tcl=-0.3)
  plot( hist.train, col=mycol60, xlim=c(-window,window),ylim=c(0,100),main=NULL,xlab="ATE error",border=FALSE,cex=0.8)  # first histogram
  plot( hist.test, col=mycol30, density=20, border=TRUE, add=T)
  #abline(v=0,lty=3,col="gray")
  abline(v=mean(results[16+nr_metrix*(i-1),]),lty=2)
  legend("topleft",c("train","test","mean"),cex=0.8,
         fill=c(mycol60,mycol30,NA),col=c(NA,NA,1),border=c(NA,mycol30,NA),density=c(1000,20,NA),lty=c(NA,NA,2))
  dev.off()
}

mymax=0
mymin=0
## ATT bias #####
for(i in 1:nr_models){
  tmp =  max(results[17+nr_metrix*(i-1),])
  if (tmp>mymax){ mymax = tmp }
  tmp =  min(results[17+nr_metrix*(i-1),])
  if (tmp<mymin){ mymin = tmp }
}
mymax=ceiling(mymax)
mymin=floor(mymin)
myseq = seq(mymin,mymax,by=0.2)

window=2
plot_w = 3; plot_h = 1.3

for(i in 1:nr_models){

  {
    hist.test  = hist(results[17+nr_metrix*(i-1),],breaks = myseq)
    hist.train = hist(results[6+nr_metrix*(i-1),],breaks = myseq)#,breaks = seq(-6,6,by=0.2))
  }

  tikz(file = sprintf("IHDP_ATThisto_full_%d.tex",i), width = plot_w, height = plot_h)
  par(mfrow=c(1,1),mar=c(2.5,2.5,0.1,0.1),mgp=c(1.3,0.3,0),cex.lab=0.8,cex.axis=0.8,tcl=-0.3)
  plot( hist.train, col=mycol60, xlim=c(-window,window),ylim=c(0,100),main=NULL,xlab="ATE error",border=FALSE,cex=0.8)  # first histogram
  plot( hist.test, col=mycol30, density=20, border=TRUE, add=T)
  #abline(v=0,lty=3,col="gray")
  abline(v=mean(results[17+nr_metrix*(i-1),]),lty=2)
  legend("topleft",c("train","test","mean"),cex=0.8,
         fill=c(mycol60,mycol30,NA),col=c(NA,NA,1),border=c(NA,mycol30,NA),density=c(1000,20,NA),lty=c(NA,NA,2))
  dev.off()
}

load("/Users/philip/Downloads/H11_100_limited_27_august.RData")
load("/Users/philip/Downloads/H11_10_limited_29_august.RData")
mymax=0
mymin=0
## ATE bias #####
for(i in 1:nr_models){
  tmp =  max(results[16+nr_metrix*(i-1),])
  if (tmp>mymax){ mymax = tmp }
  tmp =  min(results[16+nr_metrix*(i-1),])
  if (tmp<mymin){ mymin = tmp }
}
mymax=ceiling(mymax)
mymin=floor(mymin)
myseq = seq(mymin,mymax,by=0.2)

window=2
plot_w = 3; plot_h = 1.3

for(i in 1:nr_models){

  {
    hist.test  = hist(results[16+nr_metrix*(i-1),],breaks = myseq)
    hist.train = hist(results[5+nr_metrix*(i-1),],breaks = myseq)#,breaks = seq(-6,6,by=0.2))
  }

  tikz(file = sprintf("IHDP_ATEhisto_limited_%d.tex",i), width = plot_w, height = plot_h)
  par(mfrow=c(1,1),mar=c(2.5,2.5,0.1,0.1),mgp=c(1.3,0.3,0),cex.lab=0.8,cex.axis=0.8,tcl=-0.3)
  plot( hist.train, col=mycol60, xlim=c(-window,window),ylim=c(0,100),main=NULL,xlab="ATE error",border=FALSE,cex=0.8)  # first histogram
  plot( hist.test, col=mycol30, density=20, border=TRUE, add=T)
  #abline(v=0,lty=3,col="gray")
  abline(v=mean(results[16+nr_metrix*(i-1),]),lty=2)
  legend("topleft",c("train","test","mean"),cex=0.8,
         fill=c(mycol60,mycol30,NA),col=c(NA,NA,1),border=c(NA,mycol30,NA),density=c(1000,20,NA),lty=c(NA,NA,2))
  dev.off()
}

mymax=0
mymin=0
## ATT bias #####
for(i in 1:nr_models){
  tmp =  max(results[17+nr_metrix*(i-1),])
  if (tmp>mymax){ mymax = tmp }
  tmp =  min(results[17+nr_metrix*(i-1),])
  if (tmp<mymin){ mymin = tmp }
}
mymax=ceiling(mymax)
mymin=floor(mymin)
myseq = seq(mymin,mymax,by=0.2)

window=2
plot_w = 3; plot_h = 1.3

for(i in 1:nr_models){

  {
    hist.test  = hist(results[17+nr_metrix*(i-1),],breaks = myseq)
    hist.train = hist(results[6+nr_metrix*(i-1),],breaks = myseq)#,breaks = seq(-6,6,by=0.2))
  }

  tikz(file = sprintf("IHDP_ATThisto_limited_%d.tex",i), width = plot_w, height = plot_h)
  par(mfrow=c(1,1),mar=c(2.5,2.5,0.1,0.1),mgp=c(1.3,0.3,0),cex.lab=0.8,cex.axis=0.8,tcl=-0.3)
  plot( hist.train, col=mycol60, xlim=c(-window,window),ylim=c(0,100),main=NULL,xlab="ATE error",border=FALSE,cex=0.8)  # first histogram
  plot( hist.test, col=mycol30, density=20, border=TRUE, add=T)
  #abline(v=0,lty=3,col="gray")
  abline(v=mean(results[17+nr_metrix*(i-1),]),lty=2)
  legend("topleft",c("train","test","mean"),cex=0.8,
         fill=c(mycol60,mycol30,NA),col=c(NA,NA,1),border=c(NA,mycol30,NA),density=c(1000,20,NA),lty=c(NA,NA,2))
  dev.off()
}

