# CausalStumps
This package fits a Gaussian process to causal inference observational data.  It is part of my MSc project in Computational Statistics and Machine Learning at UCL in London 2016/17.

This package can be installed using following command in R:
```R
install.packages("https://github.com/mazphilip/CausalStump/raw/master/tar/CausalStump_0.1.0.tar.gz", repos = NULL, type = "source")
```


