## Load Packages #####################################################################
library(methods)
#BART
library(BayesTree)

#GPS
library(CausalStump)

#CF
library(grf)

#propensity score:
library(gbm)

#parallelization
library(foreach)
library(parallel)

#exporting to TiKz:
library(latex2exp)
library(tikzDevice)

## Predefine result files #####################################################################
#dimnames
max_iter=1
mydimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","MSE.ate","MSE.att","coverage.ite","coverage.ate","range.ate"),c("BART","CF","GP","TP2","TP100","BCF","BART.PS","CF.PS","GP.PS","TP2.PS","TP100.PS"),1:max_iter)
results_mat = array(NaN, dim=c(length(mydimnames[[1]]),length(mydimnames[[2]]),max_iter),dimnames=mydimnames)

update.results <- function(iter,index,result.item,y.hat,tau.hat,tau.ci,ate.ci,y,z,y1,y0,pscore){
  threshold = 0.1

  result.item["PEHE.all",index] = sqrt(mean((y1 - y0 - tau.hat)^2))
  result.item["PEHE.cs",index]  = sqrt(mean((y1 - y0 - tau.hat)[pscore>threshold & pscore<(1-threshold)]^2))

  result.item["E.ate",index]  = (mean(y1-y0) - mean(tau.hat))
  result.item["E.att",index]  = (mean((y1-y0)[z==1]) - mean((tau.hat)[z==1]))

  result.item["MSE.ate",index]  = (mean(y1-y0) - mean(tau.hat) )^2
  result.item["MSE.att",index]  = (mean((y1-y0)[z==1]) - mean((tau.hat)[z==1]))^2

  result.item["RMSE.all",index] = sqrt(mean((y - y.hat)^2))
  result.item["RMSE.cs",index]  = sqrt(mean((y - y.hat)[pscore>threshold & pscore<(1-threshold)]^2))

  result.item["coverage.ite",index] = mean(((tau.ci[,1] < (y1-y0)) * (tau.ci[,2] > (y1-y0))))
  result.item["coverage.ate",index] = ((ate.ci[1]< mean(y1-y0)) * (ate.ci[2] >mean(y1-y0)))

  result.item["range.ate",index] = (ate.ci[2] - ate.ci[1])

  result.item
}

## Generate Data #####################################################################
set.seed(1231)

n=120
Z = rbinom(n, 1, 0.3)
Xt = rnorm(sum(Z), mean = 40, sd = 10)
Xc = rnorm(n-sum(Z), mean = 20, sd = 10)
Xc[Xc<0] = 0.01
X = matrix(NaN,n,1)
X[Z==1,] = Xt
X[Z==0,] = Xc

y0_true = 72 + 3 * sqrt(X)
y1_true = 90 + exp(0.06 * X)
y0_true[is.nan(y0_true)] = 60
y0_true[y0_true<60] = 60
y1_true[y1_true<60] = 60
y0_true[y0_true>120] = 120
y1_true[y1_true>120] = 120

Y0 = rnorm(n, mean = y0_true, sd = 1)
Y1 = rnorm(n, mean = y1_true, sd = 1)
Y = Y0*(1-Z) + Y1*Z

CATE.true = mean(y1_true-y0_true)

mysort = sort(X,index.return=TRUE)
X.sort = mysort$x

## Generate Covariate matrices #####################################################################
X.train = X
X.test  = X

X.CS = data.frame(X)

#for BART (twice as long test file and with Z as covariate)
X.train.bart = cbind(X.train,Z)
colnames(X.train.bart) = c("X","Z")
X.test.bart = cbind(rbind(X,X),rbind(matrix(1,n,1),matrix(0,n,1)))
colnames(X.test.bart) = c("X","Z")

# ESTIMATE THE PROPENSITY SCORE --- GBM
#workaround as GBM can only use >1 input dimensions
tmpX = data.frame(cbind(X.train,Z==1,rbinom(n,1,0.5)))
colnames(tmpX) <- c("X","Z","V")
tmpX[,"Z"] = tmpX[,"Z"]==1

myPSmodel = gbm(Z ~ X+V,data = tmpX,distribution="bernoulli",
                n.trees = 2000,
                shrinkage = .1,
                cv.folds = n,
                n.cores = 3,
                interaction.depth=1
)
best.fit = gbm.perf(myPSmodel,method="cv")
tmpX[,"V"] = 0; pscore0 = predict(myPSmodel,n.trees=best.fit,type="response",newdata = tmpX)
tmpX[,"V"] = 1; pscore1 = predict(myPSmodel,n.trees=best.fit,type="response",newdata = tmpX)
pscore.gbm = (pscore0 + pscore1) * 0.5

# ESTIMATE THE PROPENSITY SCORE --- GBM
myPSbart = BayesTree::bart(x.train = X,y.train = Z,x.test=X,binaryOffset=mean(Z),ntree=200)
pscore.bart = pnorm(apply(myPSbart$yhat.test,2,mean))

pscore = pscore.bart

#BART file with PS
X.train.bart.ps = cbind(X.train.bart,pscore)
colnames(X.train.bart.ps) = c("X","Z","pscore")
X.test.bart.ps = cbind(X.test.bart,pscore)
colnames(X.test.bart.ps) = c("X","Z","pscore")

#data matrix for CF (Z is not a covariate in the matrix X)
X.train.ps = cbind(X.train,pscore)
colnames(X.train.ps) = c("X","pscore")
X.test.ps  = cbind(X.test,pscore)
colnames(X.test.ps) = c("X","pscore")

tikz(file = "ex1_surface.tex", width = 2.7, height = 2.3)
par(mfrow=c(1,1),mar=c(3.1,3.1,0.1,0.1),mgp=c(2,0.8,0),cex.lab=0.8)
plot(X,Y,ylab=TeX("$Y$"),xlab=TeX("$X$"),pch=20,ylim=c(60,125))
lines(X.sort,y1_true[mysort$ix],lty=2)
lines(X.sort,y0_true[mysort$ix],lty=2)
legend("bottomright",c("Sample","True"),lty=c(NA,2),pch=c(20,NA),cex = 0.8,bg="white")
dev.off()
tikz(file = "ex1_treat.tex", width = 2.7, height = 2.3)
par(mfrow=c(1,1),mar=c(3.1,3.1,0.1,0.1),mgp=c(2,0.8,0),cex.lab=0.8)
plot(X.sort,pscore[mysort$ix],ylim=c(0,1),type = "n",lty=1,ylab="Propensity Score",xlab=TeX("$X$"))
grid(nx=0,ny=NULL)
abline(v=20,col="lightgrey",lty=3); abline(v=40,col="lightgrey",lty=3)
lines(X.sort,pscore.gbm[mysort$ix],lty=1)
#lines(X.sort,pscore.logit[mysort$ix],lty=2)
lines(X.sort,pscore.bart[mysort$ix],lty=2)
points(X,Z,col=1,pch=20)
legend("topleft",c("Sample","GBM","BART"),lty=c(NA,1,3),pch=c(20,NA,NA),cex = 0.8,bg="white")
dev.off()

## BART #####################################################################
## fit

BART.fit = BayesTree::bart(x.train = X.train.bart,y.train = Y,x.test=X.test.bart,ntree=100,ndpost=3000,nskip=500,keepevery=1)

## obtain estimates
y.hat.bart = apply( BART.fit$yhat.train,2,mean)
tau.hat.bart = apply( (BART.fit$yhat.test[,1:n] - BART.fit$yhat.test[,(n+1):(2*n)]) ,2,mean)
ate.ci.bart = {
  tmpvar = var(apply( BART.fit$yhat.train,1,mean))
  L = mean(tau.hat.bart) - 1.96 * sqrt(tmpvar)
  U = mean(tau.hat.bart) + 1.96 * sqrt(tmpvar)
  cbind(L,U)
}

tau.ci.bart = {
  tmpsort = apply(BART.fit$yhat.test[,1:n]-BART.fit$yhat.test[,(n+1):(2*n)],2,sort)
  idx975 = round(nrow(BART.fit$yhat.test)*0.975,0)
  idx025 = round(nrow(BART.fit$yhat.test)*0.025,0)
  L = tmpsort[idx025,]
  U = tmpsort[idx975,]
  cbind(L,U)
}



## evaluate and store results
#result.item = update.results(iter,"BART",result.item,
#                             y.hat = y.hat.bart,
#                             tau.hat = tau.hat.bart,
#                             tau.ci = tau.ci.bart,
#                             ate.ci = ate.ci.bart,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

#rm(y.hat.bart,ate.ci.bart)
## BART EPS #####################################################################
## fit
BART.PS.fit = BayesTree::bart(x.train = X.train.bart.ps,y.train = Y,x.test=X.test.bart.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1)

## obtain estimates
y.hat.bart.ps   = apply( BART.PS.fit$yhat.train,2,mean)
tau.hat.bart.ps = apply( (BART.PS.fit$yhat.test[,1:n] - BART.PS.fit$yhat.test[,(n+1):(2*n)]) ,2,mean)
ate.ci.bart.ps  = {
  tmpvar = var(apply( BART.PS.fit$yhat.train,1,mean))
  L = mean(tau.hat.bart.ps) - 1.96 * sqrt(tmpvar)
  U = mean(tau.hat.bart.ps) + 1.96 * sqrt(tmpvar)
  cbind(L,U)
}

tau.ci.bart.ps = {
  tmpsort = apply(BART.PS.fit$yhat.test[,1:n]-BART.PS.fit$yhat.test[,(n+1):(2*n)],2,sort)
  idx975 = round(nrow(BART.PS.fit$yhat.test)*0.975,0)
  idx025 = round(nrow(BART.PS.fit$yhat.test)*0.025,0)
  L = tmpsort[idx025,]
  U = tmpsort[idx975,]
  cbind(L,U)
}

## evaluate and store results
#result.item = update.results(iter,"BART.PS",result.item,
#                             y.hat = y.hat.bart.ps,
#                             tau.hat = tau.hat.bart.ps,
#                             tau.ci = tau.ci.bart.ps,
#                             ate.ci = ate.ci.bart.ps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## BCF #####################################################################
#no prior on variance of prior of the treatment effect (as in Hahn et al 2017)
BCF.fit0 = BayesTree::bart(x.train = X.train.ps[Z==0,],y.train = Y[Z==0],x.test=X.train.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1,power=3.0)
BCF.fit1 = BayesTree::bart(x.train = X.train.ps[Z==1,],y.train = Y[Z==1],x.test=X.train.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1,power=3.0)


## obtain estimates
#BCF.fit1$yhat.test - BCF.fit0$yhat.test

y.hat.bcf   = apply( sweep(BCF.fit1$yhat.test,MARGIN=2,Z,`*`) + sweep(BCF.fit0$yhat.test,MARGIN=2,1-Z,`*`) ,2,mean)
tau.hat.bcf = apply( BCF.fit1$yhat.test - BCF.fit0$yhat.test ,2,mean)
ate.ci.bcf  = {
  tmpvar = var(apply( BCF.fit1$yhat.test - BCF.fit0$yhat.test ,1,mean))
  L = mean(tau.hat.bcf) - 1.96 * sqrt(tmpvar)
  U = mean(tau.hat.bcf) + 1.96 * sqrt(tmpvar)
  cbind(L,U)
}
tau.ci.bcf = {
  tmpsort = apply(BCF.fit1$yhat.test - BCF.fit0$yhat.test,2,sort)
  idx975 = round(nrow(BCF.fit1$yhat.test)*0.975,0)
  idx025 = round(nrow(BCF.fit1$yhat.test)*0.025,0)
  L = tmpsort[idx025,]
  U = tmpsort[idx975,]
  cbind(L,U)
}

## evaluate and store results
#result.item = update.results(iter,"BCF",result.item,
#                             y.hat = y.hat.bcf,
#                             tau.hat = tau.hat.bcf,
#                             tau.ci = tau.ci.bcf,
#                             ate.ci = ate.ci.bcf,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## GP #####################################################################
## need to load files as rcpp functions cannot be handed over to a parallel environment
#source("R/GPSmain.R")

## fit
GP_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=FALSE,myoptim = "GD")

## predict
GS_pred = predict(GP_fit)
GS_treat = treatment(GP_fit)

y.hat.gps = GS_pred$map
tau.hat.gps = GS_treat$map
tau.ci.gps  = GS_treat$ci
ate.ci.gps  = GS_treat$ate_ci

## evaluate and store results
#result.item = update.results(iter,"GP",result.item,
#                             y.hat = y.hat.gps,
#                             tau.hat = tau.hat.gps,
#                             tau.ci = tau.ci.gps,
#                             ate.ci = ate.ci.gps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## GPS.PS #####################################################################
## fit
GP_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=FALSE,myoptim = "Nadam")

## predict
GS_PS_pred = predict(GP_PS_fit)
GS_PS_treat = treatment(GP_PS_fit)

y.hat.gps.ps   = GS_PS_pred$map
tau.hat.gps.ps = GS_PS_treat$map
tau.ci.gps.ps  = GS_PS_treat$ci
ate.ci.gps.ps  = GS_PS_treat$ate_ci

#tau.plot("GPS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
## evaluate and store results
#result.item = update.results(iter,"GP.PS",result.item,
#                             y.hat = y.hat.gps.ps,
#                             tau.hat = tau.hat.gps.ps,
#                             tau.ci = tau.ci.gps.ps,
#                             ate.ci = ate.ci.gps.ps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## TP2 #####################################################################
## fit
TP2_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=2,myoptim = "Nadam")
#
## predict
TP2_pred = predict(TP2_fit)
TP2_treat = treatment(TP2_fit)

#
y.hat.tp2 = TP2_pred$map
tau.hat.tp2 = TP2_treat$map
tau.ci.tp2  = TP2_treat$ci
ate.ci.tp2  = TP2_treat$ate_ci

## evaluate and store results
#result.item = update.results(iter,"TP2",result.item,
#                             y.hat = y.hat.tp2,
#                             tau.hat = tau.hat.tp2,
#                             tau.ci = tau.ci.tp2,
#                             ate.ci = ate.ci.tp2,
#                             y = Y, z = Z, y1 = mysample$y1, y0 = mysample$y0 ,pscore = pscore)
#
## TP2.PS #####################################################################
## fit
TP2_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=2,myoptim = "Nadam")
#
## predict
TP2_PS_pred = predict(TP2_PS_fit)
TP2_PS_treat = treatment(TP2_PS_fit)

#
y.hat.tp2.ps   = TP2_PS_pred$map
tau.hat.tp2.ps = TP2_PS_treat$map
tau.ci.tp2.ps  = TP2_PS_treat$ci
ate.ci.tp2.ps  = TP2_PS_treat$ate_ci
#
#tau.plot("GPS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
## evaluate and store results
#result.item = update.results(iter,"TP2.PS",result.item,
#                             y.hat = y.hat.tp2.ps,
#                             tau.hat = tau.hat.tp2.ps,
#                             tau.ci = tau.ci.tp2.ps,
#                             ate.ci = ate.ci.tp2.ps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)
#
## TP100 #####################################################################
## need to load files as rcpp functions cannot be handed over to a parallel environment
#
## fit
TP100_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.0001,prior=TRUE,nu=100,myoptim = "GD")
#
## predict
TP100_pred = predict(TP100_fit)
TP100_treat = treatment(TP100_fit)
#
y.hat.tp100 = TP100_pred$map
tau.hat.tp100 = TP100_treat$map
tau.ci.tp100  = TP100_treat$ci
ate.ci.tp100  = TP100_treat$ate_ci
#
## evaluate and store results
#result.item = update.results(iter,"TP100",result.item,
#                             y.hat = y.hat.tp100,
#                             tau.hat = tau.hat.tp100,
#                             tau.ci = tau.ci.tp100,
#                             ate.ci = ate.ci.tp100,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)
#
## TP100.PS #####################################################################
## fit
TP100_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.001,prior=TRUE,nu=100,myoptim = "Nadam")
#
## predict
TP100_PS_pred = predict(TP100_PS_fit)
TP100_PS_treat = treatment(TP100_PS_fit)

#
y.hat.tp100.ps   = TP100_PS_pred$map
tau.hat.tp100.ps = TP100_PS_treat$map
tau.ci.tp100.ps  = TP100_PS_treat$ci
ate.ci.tp100.ps  = TP100_PS_treat$ate_ci


## evaluate and store results
#result.item = update.results(iter,"TP100.PS",result.item,
#                             y.hat = y.hat.tp100.ps,
#                             tau.hat = tau.hat.tp100.ps,
#                             tau.ci = tau.ci.tp100.ps,
#                             ate.ci = ate.ci.tp100.ps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## CF #####################################################################
## fit
CF.forest = grf::causal_forest(X = X.train,Y =  Y, W = Z, num.trees = 5000,precompute.nuisance = TRUE,num.threads=2)

## predict
CF.pred   = predict(CF.forest, X.test = X.test, estimate.variance = TRUE,num.threads=2)

y.hat.cf   = CF.forest$Y.hat
tau.hat.cf = CF.pred$predictions
tau.ci.cf  = cbind(tau.hat.cf - 1.96 *sqrt(CF.pred$variance.estimates),
                   tau.hat.cf + 1.96 *sqrt(CF.pred$variance.estimates))
#cannot get confidence interval for CF

ate.ci.cf  =  { tmp.ate = grf::estimate_average_effect(CF.forest, target.sample = "all");
c(tmp.ate["estimate"] - 1.96 * tmp.ate["std.err"],
  tmp.ate["estimate"] + 1.96 * tmp.ate["std.err"])}

## evaluate and store results
#result.item = update.results(iter,"CF",result.item,
#                             y.hat = y.hat.cf,
#                             tau.hat = tau.hat.cf,
#                             tau.ci = tau.ci.cf,
#                             ate.ci = ate.ci.cf,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## CF.PS #####################################################################

## fit
CF.PS.forest = grf::causal_forest(X = X.train.ps,Y =  Y, W = Z, num.trees = 5000,precompute.nuisance = TRUE,num.threads=1)

## predict
CF.PS.pred   = predict(CF.PS.forest, X.test = X.test, estimate.variance = TRUE,num.threads=1)

y.hat.cf.ps   = CF.PS.forest$Y.hat
tau.hat.cf.ps = CF.PS.pred$predictions
tau.ci.cf.ps  = cbind(tau.hat.cf - 1.96 *sqrt(CF.PS.pred$variance.estimates),
                      tau.hat.cf + 1.96 *sqrt(CF.PS.pred$variance.estimates))
#cannot get confidence interval for CF

ate.ci.cf.ps  =  { tmp.ate = grf::estimate_average_effect(CF.PS.forest, target.sample = "all");
c(tmp.ate["estimate"] - 1.96 * tmp.ate["std.err"],
  tmp.ate["estimate"] + 1.96 * tmp.ate["std.err"])}

## evaluate and store results
#result.item = update.results(iter,"CF.PS",result.item,
#                             y.hat = y.hat.cf.ps,
#                             tau.hat = tau.hat.cf.ps,
#                             tau.ci = tau.ci.cf.ps,
#                             ate.ci = ate.ci.cf.ps,
#                             y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

## synRF ####
library(randomForestSRC)
synRF.fit = rfsrcSyn(Y ~ .,data = data.frame(cbind(Y=Y,X.train.ps,Z=Z) ) )
synRF.fit0 = rfsrcSyn(Y ~ .,data = data.frame(cbind(Y=Y[Z==0],X.train.ps[Z==0,]) ) )
synRF.fit1 = rfsrcSyn(Y ~ ., data= data.frame(cbind(Y=Y[Z==1],X.train.ps[Z==1,]) ) )

RF.pred0 = predict(synRF.fit, newdata = cbind(X.train.ps,Z = rep(0,n) ))
RF.pred1 = predict(synRF.fit, newdata = cbind(X.train.ps,Z = rep(1,n) ))


rfsrcSyn(object = ringSyn2, newdata = ring.test)$rfSynPred
RF.pred1 = predict(synRF.fit1, dat = cbind(X.train.ps,Z = rep(1,n) ))

treat_RLT = RF.pred1$predictions - RF.pred0$predictions
plot(y1_true - y0_true,treat_RLT);abline(0,1)

tau.plot("TP100",treat_RLT, ci = cbind(rep(0,n),rep(0,n)))
plot(X.sort,RF.pred0$predictions[mysort$ix])
points(X.sort,RF.pred1$predictions[mysort$ix])




## Plots #############################
tau.plot <- function(name,tau.hat,sd,ci){
  par(mfrow=c(1,1),mar=c(2.5,2.5,0.1,0.1),mgp=c(1.3,0.3,0),cex.lab=0.8,cex.axis=0.8,tcl=-0.3)
  plot(X,tau.hat,type="n",ylim=c(0,30),ylab = "Treatment effect",xlab =TeX("$X$"))#,main=name
  #axis(side = 1, tck = -.01);axis(side = 2,tck = -.01,tcl)

  if(!missing(sd)){
    L = tau.hat - 1.96 * sd
    U = tau.hat + 1.96 * sd
  } else {
    L = ci[,1]
    U = ci[,2]
  }
  polygon(c(X.sort,rev(X.sort)),c(L[mysort$ix],rev(U[mysort$ix])),col = "grey75", border = FALSE)
  lines(X.sort,(y1_true-y0_true)[mysort$ix],lty=2)
  points(X,tau.hat,pch=20)
}
plot_w = 3; plot_h = 1.3

tikz(file = "ex1_bart.tex", width = plot_w, height = plot_h)
tau.plot("BART",tau.hat.bart,ci = tau.ci.bart)
dev.off()
tikz(file = "ex1_cf.tex", width = plot_w, height = plot_h)
tau.plot("CF",tau.hat.cf,ci = tau.ci.cf)
dev.off()
tikz(file = "ex1_gps.tex", width = plot_w, height = plot_h)
tau.plot("GPS",tau.hat.gps,ci = tau.ci.gps)
dev.off()
tikz(file = "ex1_bcf.tex", width = plot_w, height = plot_h)
tau.plot("BCF",tau.hat.bcf,ci = tau.ci.bcf)
dev.off()
tikz(file = "ex1_bartps.tex", width = plot_w, height = plot_h)
tau.plot("BART.PS",tau.hat.bart.ps,ci = tau.ci.bart.ps)
dev.off()
tikz(file = "ex1_cfps.tex", width = plot_w, height = plot_h)
tau.plot("CF.PS",tau.hat.cf.ps,ci = tau.ci.cf.ps)
dev.off()
tikz(file = "ex1_gpsps.tex", width = plot_w, height = plot_h)
tau.plot("GPS.PS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
dev.off()
tikz(file = "ex1_tp2.tex", width = plot_w, height = plot_h)
tau.plot("TP2",tau.hat.tp2,ci = tau.ci.tp2)
dev.off()
tikz(file = "ex1_tp2ps.tex", width = plot_w, height = plot_h)
tau.plot("TP2.PS",tau.hat.tp2.ps,ci = tau.ci.tp2.ps)
dev.off()
tikz(file = "ex1_tp100.tex", width = plot_w, height = plot_h)
tau.plot("TP100",tau.hat.tp100, ci = tau.ci.tp100)
dev.off()
tikz(file = "ex1_tp100ps.tex", width = plot_w, height = plot_h)
tau.plot("TP100.PS",tau.hat.tp100.ps,ci = tau.ci.tp100.ps)
dev.off()

