# CausalStumps
This package fits a Gaussian process to causal inference observational data.  It is part of my MSc project in Computational Statistics and Machine Learning at UCL in London 2016/17.


