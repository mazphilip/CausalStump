# GP with SE kernel
source("R/kernel_GP_SE_class.R")
# TP with SE kernel
source("R/kernel_TP_SE_class.R")
