## Load Packages #####################################################################
#BART
library(BayesTree)
library(mvnfast)
library(methods)

#GPS
library(Rcpp)
library(RcppArmadillo)
source("R/GPSmain.R")

#CF
library(grf)

#for the propensity score:
#library(rms)
library(gbm)

library(foreach)
library(parallel)


#exporting to TiKz:
#library(latex2exp)
#library(tikzDevice)

## Experiment length setup #####################################################################

max_iter=100

## Predefine result files #####################################################################
#dimnames

mydimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","MSE.ate","MSE.att","coverage.ite","coverage.ate","range.ate"),c("BART","CF","GP","TP2","TP100","BCF","BART.PS","CF.PS","GP.PS","TP2.PS","TP100.PS"),1:max_iter)
results_mat = array(NaN, dim=c(length(mydimnames[[1]]),length(mydimnames[[2]]),max_iter),dimnames=mydimnames)

update.results <- function(iter,index,result.item,y.hat,tau.hat,tau.ci,ate.ci,y,z,y1,y0,pscore){
  threshold = 0.1

  result.item["PEHE.all",index] = sqrt(mean((y1 - y0 - tau.hat)^2))
  result.item["PEHE.cs",index]  = sqrt(mean((y1 - y0 - tau.hat)[pscore>threshold & pscore<(1-threshold)]^2))

  result.item["E.ate",index]  = (mean(y1-y0) - mean(tau.hat))
  result.item["E.att",index]  = (mean((y1-y0)[z==1]) - mean((tau.hat)[z==1]))

  result.item["MSE.ate",index]  = (mean(y1-y0) - mean(tau.hat) )^2
  result.item["MSE.att",index]  = (mean((y1-y0)[z==1]) - mean((tau.hat)[z==1]))^2

  result.item["RMSE.all",index] = sqrt(mean((y - y.hat)^2))
  result.item["RMSE.cs",index]  = sqrt(mean((y - y.hat)[pscore>threshold & pscore<(1-threshold)]^2))

  result.item["coverage.ite",index] = mean(((tau.ci[,1] < (y1-y0)) * (tau.ci[,2] > (y1-y0))))
  result.item["coverage.ate",index] = ((ate.ci[1]< mean(y1-y0)) * (ate.ci[2] >mean(y1-y0)))

  result.item["range.ate",index] = (ate.ci[2] - ate.ci[1])

  result.item
}

## Run experiment Loop #####################################################################
#for(iter in 1:max_iter){
run <- function(iter){
  mydimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","MSE.ate","MSE.att","coverage.ite","coverage.ate","range.ate"),c("BART","CF","GP","TP2","TP100","BCF","BART.PS","CF.PS","GP.PS","TP2.PS","TP100.PS"))


  ## Generate Data #####################################################################
  set.seed(1230+iter)

  n=120
  Z = rbinom(n, 1, 0.3)
  Xt = rnorm(sum(Z), mean = 40, sd = 10)
  Xc = rnorm(n-sum(Z), mean = 20, sd = 10)
  Xc[Xc<0] = 0.01
  X = matrix(NaN,n,1)
  X[Z==1,] = Xt
  X[Z==0,] = Xc

  y0_true = 72 + 3 * sqrt(X)
  y1_true = 90 + exp(0.06 * X)
  y0_true[is.nan(y0_true)] = 60
  y0_true[y0_true<60] = 60
  y1_true[y1_true<60] = 60
  y0_true[y0_true>120] = 120
  y1_true[y1_true>120] = 120

  Y0 = rnorm(n, mean = y0_true, sd = 1)
  Y1 = rnorm(n, mean = y1_true, sd = 1)
  Y = Y0*(1-Z) + Y1*Z

  CATE.true = mean(y1_true-y0_true)

  mysort = sort(X,index.return=TRUE)
  X.sort = mysort$x

  ## Generate Covariate matrices #####################################################################
  X.train = X
  X.test  = X

  X.CS = data.frame(X)

  #for BART (twice as long test file and with Z as covariate)
  X.train.bart = cbind(X.train,Z)
  colnames(X.train.bart) = c("X","Z")
  X.test.bart = cbind(rbind(X,X),rbind(matrix(1,n,1),matrix(0,n,1)))
  colnames(X.test.bart) = c("X","Z")

  # ESTIMATE THE PROPENSITY SCORE --- BART
  myPSbart = BayesTree::bart(x.train = X,y.train = Z,x.test=X,binaryOffset=mean(Z),ntree=200)
  pscore = pnorm(apply(myPSbart$yhat.test,2,mean))

  #BART file with PS
  X.train.bart.ps = cbind(X.train.bart,pscore)
  colnames(X.train.bart.ps) = c("X","Z","pscore")
  X.test.bart.ps = cbind(X.test.bart,pscore)
  colnames(X.test.bart.ps) = c("X","Z","pscore")

  #data matrix for GPS and CF (Z is not a covariate in the matrix X)
  X.train.ps = cbind(X.train,pscore)
  colnames(X.train.ps) = c("X","pscore")
  X.test.ps  = cbind(X.test,pscore)
  colnames(X.test.ps) = c("X","pscore")

  result.item = matrix(NaN, length(mydimnames[[1]]),length(mydimnames[[2]]),dimnames=list(mydimnames[[1]],mydimnames[[2]]) )

  ## BART #####################################################################
  ## fit

  BART.fit = BayesTree::bart(x.train = X.train.bart,y.train = Y,x.test=X.test.bart,ntree=100,ndpost=3000,nskip=500,keepevery=1)

  ## obtain estimates
  y.hat.bart = apply( BART.fit$yhat.train,2,mean)
  tau.hat.bart = apply( (BART.fit$yhat.test[,1:n] - BART.fit$yhat.test[,(n+1):(2*n)]) ,2,mean)
  ate.ci.bart = {
    tmpvar = var(apply( BART.fit$yhat.train,1,mean))
    L = mean(tau.hat.bart) - 1.96 * sqrt(tmpvar)
    U = mean(tau.hat.bart) + 1.96 * sqrt(tmpvar)
    cbind(L,U)
  }

  #tau.ci.bart = {
  #  tmpvar = var(apply( BART.fit$yhat.train,1,mean))
  #  L = (tau.hat.bart) - 1.96 * sqrt(tmpvar)
  #  U = (tau.hat.bart) + 1.96 * sqrt(tmpvar)
  #  cbind(L,U)
  #}
  tau.ci.bart = {
    tmpsort = apply(BART.fit$yhat.test[,1:n]-BART.fit$yhat.test[,(n+1):(2*n)],2,sort)
    idx975 = round(nrow(BART.fit$yhat.test)*0.975,0)
    idx025 = round(nrow(BART.fit$yhat.test)*0.025,0)
    L = tmpsort[idx025,]
    U = tmpsort[idx975,]
    cbind(L,U)
  }



  ## evaluate and store results
  result.item = update.results(iter,"BART",result.item,
                               y.hat = y.hat.bart,
                               tau.hat = tau.hat.bart,
                               tau.ci = tau.ci.bart,
                               ate.ci = ate.ci.bart,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  #rm(y.hat.bart,ate.ci.bart)
  ## BART EPS #####################################################################
  ## fit
  BART.PS.fit = BayesTree::bart(x.train = X.train.bart.ps,y.train = Y,x.test=X.test.bart.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1)

  ## obtain estimates
  y.hat.bart.ps   = apply( BART.PS.fit$yhat.train,2,mean)
  tau.hat.bart.ps = apply( (BART.PS.fit$yhat.test[,1:n] - BART.PS.fit$yhat.test[,(n+1):(2*n)]) ,2,mean)
  ate.ci.bart.ps  = {
    tmpvar = var(apply( BART.PS.fit$yhat.train,1,mean))
    L = mean(tau.hat.bart.ps) - 1.96 * sqrt(tmpvar)
    U = mean(tau.hat.bart.ps) + 1.96 * sqrt(tmpvar)
    cbind(L,U)
  }

  tau.ci.bart.ps = {
    tmpsort = apply(BART.PS.fit$yhat.test[,1:n]-BART.PS.fit$yhat.test[,(n+1):(2*n)],2,sort)
    idx975 = round(nrow(BART.PS.fit$yhat.test)*0.975,0)
    idx025 = round(nrow(BART.PS.fit$yhat.test)*0.025,0)
    L = tmpsort[idx025,]
    U = tmpsort[idx975,]
    cbind(L,U)
  }

  ## evaluate and store results
  result.item = update.results(iter,"BART.PS",result.item,
                               y.hat = y.hat.bart.ps,
                               tau.hat = tau.hat.bart.ps,
                               tau.ci = tau.ci.bart.ps,
                               ate.ci = ate.ci.bart.ps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## BCF #####################################################################
  #no prior on variance of prior of the treatment effect (as in Hahn et al 2017)
  BCF.fit0 = BayesTree::bart(x.train = X.train.ps[Z==0,],y.train = Y[Z==0],x.test=X.train.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1,power=3.0)
  BCF.fit1 = BayesTree::bart(x.train = X.train.ps[Z==1,],y.train = Y[Z==1],x.test=X.train.ps,ntree=100,ndpost=3000,nskip=500,keepevery=1,power=3.0)


  ## obtain estimates
  #BCF.fit1$yhat.test - BCF.fit0$yhat.test

  y.hat.bcf   = apply( sweep(BCF.fit1$yhat.test,MARGIN=2,Z,`*`) + sweep(BCF.fit0$yhat.test,MARGIN=2,1-Z,`*`) ,2,mean)
  tau.hat.bcf = apply( BCF.fit1$yhat.test - BCF.fit0$yhat.test ,2,mean)
  ate.ci.bcf  = {
    tmpvar = var(apply( BCF.fit1$yhat.test - BCF.fit0$yhat.test ,1,mean))
    L = mean(tau.hat.bcf) - 1.96 * sqrt(tmpvar)
    U = mean(tau.hat.bcf) + 1.96 * sqrt(tmpvar)
    cbind(L,U)
  }
  tau.ci.bcf = {
    tmpsort = apply(BCF.fit1$yhat.test - BCF.fit0$yhat.test,2,sort)
    idx975 = round(nrow(BCF.fit1$yhat.test)*0.975,0)
    idx025 = round(nrow(BCF.fit1$yhat.test)*0.025,0)
    L = tmpsort[idx025,]
    U = tmpsort[idx975,]
    cbind(L,U)
  }

  ## evaluate and store results
  result.item = update.results(iter,"BCF",result.item,
                               y.hat = y.hat.bcf,
                               tau.hat = tau.hat.bcf,
                               tau.ci = tau.ci.bcf,
                               ate.ci = ate.ci.bcf,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## GP #####################################################################
  ## need to load files as rcpp functions cannot be handed over to a parallel environment
  #source("R/GPSmain.R")

  ## fit
  X.train.dummy = data.frame("X" = X.train,"dum" = rep(0,n))
  GP_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=FALSE,myoptim = "Nadam")

  ## predict
  GS_pred = predict_surface(X.CS,Z,GP_fit)
  GS_treat = predict_treatment(X.CS,GP_fit)

  y.hat.gps = GS_pred$map
  tau.hat.gps = GS_treat$map
  tau.ci.gps  = GS_treat$ci
  ate.ci.gps  = GS_treat$ate_ci
  print("GP CI")
  print(GS_treat)

  ## evaluate and store results
  result.item = update.results(iter,"GP",result.item,
                               y.hat = y.hat.gps,
                               tau.hat = tau.hat.gps,
                               tau.ci = tau.ci.gps,
                               ate.ci = ate.ci.gps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## GPS.PS #####################################################################
  ## fit
  GP_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=FALSE,myoptim = "Nadam")

  ## predict
  GS_PS_pred = predict_surface(X.CS,Z,GP_PS_fit,pscore=pscore)
  GS_PS_treat = predict_treatment(X.CS,GP_PS_fit,pscore=pscore)

  y.hat.gps.ps   = GS_PS_pred$map
  tau.hat.gps.ps = GS_PS_treat$map
  tau.ci.gps.ps  = GS_PS_treat$ci
  ate.ci.gps.ps  = GS_PS_treat$ate_ci

  #tau.plot("GPS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
  ## evaluate and store results
  result.item = update.results(iter,"GP.PS",result.item,
                               y.hat = y.hat.gps.ps,
                               tau.hat = tau.hat.gps.ps,
                               tau.ci = tau.ci.gps.ps,
                               ate.ci = ate.ci.gps.ps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## TP2 #####################################################################
  ## need to load files as rcpp functions cannot be handed over to a parallel environment
  #source("GPSbasics.R")
  #source("R/GPSmain.R")
#
  ## fit
  TP2_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=2,myoptim = "Nadam")
#
  ## predict
  TP2_pred = predict_surface(X.CS,Z,TP2_fit)
  TP2_treat = predict_treatment(X.CS,TP2_fit)
#
  y.hat.gps   = TP2_pred$map
  tau.hat.gps = TP2_treat$map
  tau.ci.gps  = TP2_treat$ci
  ate.ci.gps  = TP2_treat$ate_ci
#
  ## evaluate and store results
  result.item = update.results(iter,"TP2",result.item,
                               y.hat = y.hat.gps,
                               tau.hat = tau.hat.gps,
                               tau.ci = tau.ci.gps,
                               ate.ci = ate.ci.gps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)
#
  ## TP2.PS #####################################################################
  ## fit
  TP2_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=2,myoptim = "Nadam")
#
  ## predict
  TP2_PS_pred = predict_surface(X.CS,Z,TP2_PS_fit,pscore=pscore)
  TP2_PS_treat = predict_treatment(X.CS,TP2_PS_fit,pscore=pscore)
#
  y.hat.gps.ps   = TP2_PS_pred$map
  tau.hat.gps.ps = TP2_PS_treat$map
  tau.ci.gps.ps  = TP2_PS_treat$ci
  ate.ci.gps.ps  = TP2_PS_treat$ate_ci
#
  #tau.plot("GPS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
  ## evaluate and store results
  result.item = update.results(iter,"TP2.PS",result.item,
                               y.hat = y.hat.gps.ps,
                               tau.hat = tau.hat.gps.ps,
                               tau.ci = tau.ci.gps.ps,
                               ate.ci = ate.ci.gps.ps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)
#
  ## TP100 #####################################################################
  ## need to load files as rcpp functions cannot be handed over to a parallel environment
#
  ## fit
  TP100_fit = CausalStump(Y,X.CS,Z,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=100,myoptim = "Nadam")
#
  ## predict
  TP100_pred = predict_surface(X.CS,Z,TP100_fit)
  TP100_treat = predict_treatment(X.CS,TP100_fit)
#
  y.hat.gps = TP100_pred$map
  tau.hat.gps = TP100_treat$map
  tau.ci.gps  = TP100_treat$ci
  ate.ci.gps  = TP100_treat$ate_ci
#
  ## evaluate and store results
  result.item = update.results(iter,"TP100",result.item,
                               y.hat = y.hat.gps,
                               tau.hat = tau.hat.gps,
                               tau.ci = tau.ci.gps,
                               ate.ci = ate.ci.gps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)
#
  ## TP100.PS #####################################################################
  ## fit
  TP100_PS_fit = CausalStump(Y,X.CS,Z,pscore=pscore,maxiter=5000,tol=1e-4,learning_rate = 0.01,prior=TRUE,nu=100,myoptim = "Nadam")
#
  ## predict
  TP100_PS_pred = predict_surface(X.CS,Z,TP100_PS_fit,pscore=pscore)
  TP100_PS_treat = predict_treatment(X.CS,TP100_PS_fit,pscore=pscore)
#
  y.hat.gps.ps   = TP100_PS_pred$map
  tau.hat.gps.ps = TP100_PS_treat$map
  tau.ci.gps.ps  = TP100_PS_treat$ci
  ate.ci.gps.ps  = TP100_PS_treat$ate_ci
#
  #tau.plot("GPS",tau.hat.gps.ps,ci = tau.ci.gps.ps)
  ## evaluate and store results
  result.item = update.results(iter,"TP100.PS",result.item,
                               y.hat = y.hat.gps.ps,
                               tau.hat = tau.hat.gps.ps,
                               tau.ci = tau.ci.gps.ps,
                               ate.ci = ate.ci.gps.ps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## CF #####################################################################
  ## fit
  CF.forest = grf::causal_forest(X = X.train,Y =  Y, W = Z, num.trees = 10000,precompute.nuisance = TRUE,num.threads=2)

  ## predict
  CF.pred   = predict(CF.forest, X.test = X.test, estimate.variance = TRUE,num.threads=2)

  y.hat.cf   = CF.forest$Y.hat
  tau.hat.cf = CF.pred$predictions
  tau.ci.cf  = cbind(tau.hat.cf - 1.96 *sqrt(CF.pred$variance.estimates),
                     tau.hat.cf + 1.96 *sqrt(CF.pred$variance.estimates))
  #cannot get confidence interval for CF

  ate.ci.cf  =  { tmp.ate = grf::estimate_average_effect(CF.forest, target.sample = "all");
  c(tmp.ate["estimate"] - 1.96 * tmp.ate["std.err"],
    tmp.ate["estimate"] + 1.96 * tmp.ate["std.err"])}

  ## evaluate and store results
  result.item = update.results(iter,"CF",result.item,
                               y.hat = y.hat.cf,
                               tau.hat = tau.hat.cf,
                               tau.ci = tau.ci.cf,
                               ate.ci = ate.ci.cf,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)

  ## CF.PS #####################################################################

  ## fit
  CF.PS.forest = grf::causal_forest(X = X.train.ps,Y =  Y, W = Z, num.trees = 5000,precompute.nuisance = TRUE,num.threads=1)

  ## predict
  CF.PS.pred   = predict(CF.PS.forest, X.test = X.test, estimate.variance = TRUE,num.threads=1)

  y.hat.cf.ps   = CF.PS.forest$Y.hat
  tau.hat.cf.ps = CF.PS.pred$predictions
  tau.ci.cf.ps  = cbind(tau.hat.cf - 1.96 *sqrt(CF.PS.pred$variance.estimates),
                        tau.hat.cf + 1.96 *sqrt(CF.PS.pred$variance.estimates))
  #cannot get confidence interval for CF

  ate.ci.cf.ps  =  { tmp.ate = grf::estimate_average_effect(CF.PS.forest, target.sample = "all");
  c(tmp.ate["estimate"] - 1.96 * tmp.ate["std.err"],
    tmp.ate["estimate"] + 1.96 * tmp.ate["std.err"])}

  ## evaluate and store results
  result.item = update.results(iter,"CF.PS",result.item,
                               y.hat = y.hat.cf.ps,
                               tau.hat = tau.hat.cf.ps,
                               tau.ci = tau.ci.cf.ps,
                               ate.ci = ate.ci.cf.ps,
                               y = Y, z = Z, y1 = y1_true, y0 = y0_true,pscore = pscore)


  cat("Iteration ",iter, " finished\n")
  #return results matrix
  result.item
  #list(results = result.item,ci =  tau.ci.gps.ps)
} # end of run


## Run #####
#print("single run test")
#system.time(results <- run(1)) # 1 ... 230 sec, 3min 50sec on AWS: 226 sec, AWS parSapplyLB: 235.744sec
#system.time(parSapplyLB(cl,1:max_iter,run)) # 2 parallel ... 229.4 sec, 3min 49sec
#system.time(parSapplyLB(cl,1:max_iter,run)) # 10parallel ... 1070.517 sec, 17min 51 sec
#system.time(parSapply(cl,1:max_iter,run)) # 10parallel ... 1800 sec, 30min

#2 iterations on 35 cores didnt work well


max_iter=100
#max_iter=100
nr_cores = detectCores()
print(sprintf("Iterations: %d on %d cores",max_iter,nr_cores))
#cl <- makeForkCluster(nr_cores)
#clusterExport(cl, list("update.results", "foreach", "%do%","sourceCpp","rmvt"))

system.time(results <- sapply(1:max_iter,run)) #clusterApplyLB, parSapply
#stopCluster(cl)

#results[[1]]$results

#row means
#print("means")
#results.mean = matrix(apply(results,1,mean),11,10,dimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","coverage.ite","coverage.ate"),c("BART","CF","GPS","BART.PS","CF.PS","GPS.PS")))
#results.mean
#print("se")
#results.se = matrix(sqrt(apply(results,1,var)),8,6,dimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","coverage.ite","coverage.ate"),c("BART","CF","GPS","BART.PS","CF.PS","GPS.PS")))
#results.se
save.image(file = paste("ex1_",max_iter,"_12_august.RData",sep=""))
#results[47,]

library(xtable)
load("/Users/philip/Downloads/ex1_100_12_august.RData")
mydimnames = list(c("PEHE.all","PEHE.cs","RMSE.all","RMSE.cs","E.ate","E.att","MSE.ate","MSE.att","coverage.ite","coverage.ate","range.ate"),c("BART","CF","GP","TP2","TP100","BCF","BART.PS","CF.PS","GP.PS","TP2.PS","TP100.PS"))
out = round(cbind(matrix(apply(results,1,mean),11,11),sqrt(matrix(apply(results,1,var),11,11)),matrix(apply(results,1,min),11,11),matrix(apply(results,1,max),11,11)),2)
out2 = matrix(NaN,11*4,11)
colnames(out2) <- mydimnames[[2]]
for(i in  1:4){
  for(j in 1:11)
    #    all "means" for method "j" , <-
  out2[(1:11 -1) * 4 + i, j] <- c(out[,j + 11*(i-1) ])
}
xtable(out2)


